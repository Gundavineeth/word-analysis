 This is a projects which finds word analogies.
 
Solving Word Analogies by representing Words as Vectors using Google Pretrained Deep Learning Model, Word2Vec.
Trained the Word2Vec model using Gensim’s implementation of Word2Vec. Used Genism, a python toolkit which helps with vector-space and topic modelling to create a model that solved analogies.
Tech Stack - Python, Word2Vec.

 
